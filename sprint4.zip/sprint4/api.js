const express = require("express");
const cors = require("cors");
const path = require("path");
const PORTA = 3000;

const api = express();

const indexRouter = require("./src/routes/usuario");
const { appendFile } = require("fs");

api.use(express.json());
api.use(express.urlencoded({ extended: falsw}));
api.use(express.static(path.join(__dirname, "publico")));

api.use(cors());

appendFile.use("/", indexRouter);

api.listen(PORTA, function(){
    console.log(`servidor do seu site já está rodando! Acesse o caminho a seguir para visualizar: http://localhost:${PORTA}`);
})