const express = require("express");
const router = express.Router();

const usuarioController = require("../controllers/usuarioController.js");

router.post("/entrar", function(req, res){
    usuarioController.entrar(req, res);
});

router.post("/cadastrar", function(req, res){
    usuarioController.cadastrar(req,res);
})

module.exports = router;