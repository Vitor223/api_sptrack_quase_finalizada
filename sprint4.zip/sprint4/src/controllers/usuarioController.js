const usuarioModel = require("../Models/usuarioModel");

function entrar(req, res){

const email = req.body.emailServer;
const senha = req.body.senhaServer;

if(email == undefined){
    res.status(400).send("Peencha o seu e-mail corretamente!");

}
else if(senha == undefined){
    res.status(400).send("Preencha a sua senha corretamente!");
}
else{
    usuarioModel.entrar(email, senha)
    .then((resultado) => {
        console.log(`Resultados encontrados: ${resultado.length}`);
        console.log(`Resultados: ${JSON.stringify(resultado)}`);

        if(resultado.length == 1){
            console.log(resultado);
            res.json(resultado[0]);
        }
        else if(resultado.length == 0){
            res.status(403).send("E-mail e/ou senha inválido(s)");

        }
        else{
            res.status(403).send("Mais de um usuário com o mesmo login e senha");
        }
    })

    .catch((erro) =>{
        console.log(erro);
        console.log(`Houve um erro ao realizar o login! Erro: ${erro.sqlMessege}`);
        res.status(500).json(erro.sqlMessege);
    });
}

}

function cadastrar(req, res){
    const nome = req.body.nomeServer;
    const  usuario = req.body.usuarioServer;
    const email = req.body.emailServer;
    const senha = req.body.senhaServer;
    const tipo = req.body.tipoServer;

    if(email == undefined){
        res.status(400).send("Preencha o seu e-mail corretamente!");
    }
    else if(senha == undefined){
        res.status(400).send("Preencha a sua senha corretamente!");
    }
    else if(nome == undefined){
        res.status(400).send("Preencha o seu nome corretamente!");
    }

    else if(usuario == undefined){
        res.status(400).send("Preencha sua data de nascimento corretamente");
    }

    else if(tipo == undefined){
        res.status(400).send("Preencha o seu nome de Usuario corretamente!");
    }

    else
    {
        
    }
}

modules.exports = {

    entrar
}