const database = require("../database/config");

function entrar(email, senha){
    console.log(`Acessei o usuarioModel. Function entrar(${email}, ${senha})`);
    const comando = `SELECT * FRM Usuario WHERE email = '${email}' AND senha = '${senha}'`;

    console.log(`Executando a instrução SQL: ${comando}`);
    return database.executar(comando);
}

modules.exports = {
    entrar
}